package com.employee.NewProgram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewProgramApplication.class, args);
	}

}
