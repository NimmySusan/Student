package com.employee.NewProgram.services;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.employee.NewProgram.domain.Student;

@Service
public interface StudentService extends JpaRepository<Student,Long>
{

}
